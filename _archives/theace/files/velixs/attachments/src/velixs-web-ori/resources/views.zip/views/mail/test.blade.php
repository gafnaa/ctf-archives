<!DOCTYPE html>
<html>
<head>
    <title>santrikoding.com</title>
</head>
<body>

    <p>Terimakasih</p>
</body>
</html>
