@extends('layouts.dash.main')

@section('content')
<main class="flex-1 dark:text-gray-50 text-gray-900">
    <div class="py-6">
        <div class="mx-auto px-4 sm:px-6 md:px-8">
            <div class="bg-white dark:bg-gray-800 w-full border p-3 dark:border-gray-800 rounded-xl overflow-hidden shadow sm:rounded-lg">
                <div class="px-4 py-5 sm:p-6">

                </div>
            </div>
        </div>
    </div>
</main>
@endsection
